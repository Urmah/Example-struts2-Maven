# Example-struts2-maven
Ejemplo proyecto java struts2 con Maven
